const productos = [
    { nombre: "Campera", precio: 12000 },
    { nombre: "Gorra", precio: 3000 },
    { nombre: "Pantalón", precio: 8000 },
    { nombre: "Remera", precio: 5000 },
    { nombre: "Zapatillas", precio: 15000 }
];

let carritoProductos = JSON.parse(localStorage.getItem('carrito')) || [];

const productosDisponiblesDiv = document.getElementById('productosDisponibles');
const carritoDiv = document.getElementById('carrito');
const verCarritoBtn = document.getElementById('verCarrito');
const vaciarCarritoBtn = document.getElementById('vaciarCarrito');

function mostrarProductos() {
    productosDisponiblesDiv.innerHTML = "<h2>Productos Disponibles</h2>";
    productos.forEach(producto => {
        const productoDiv = document.createElement('div');
        productoDiv.innerHTML = `<span>${producto.nombre} - $${producto.precio}</span>
                                 <button onclick="agregarAlCarrito('${producto.nombre}', ${producto.precio})">Agregar</button>`;
        productosDisponiblesDiv.appendChild(productoDiv);
    });
}

function agregarAlCarrito(nombre, precio) {
    const producto = { nombre, precio };
    carritoProductos.push(producto);
    localStorage.setItem('carrito', JSON.stringify(carritoProductos));
    actualizarCarrito();
}

function eliminarDelCarrito(index) {
    carritoProductos.splice(index, 1);
    localStorage.setItem('carrito', JSON.stringify(carritoProductos));
    actualizarCarrito();
}

function mostrarCarrito() {
    if (carritoProductos.length === 0) {
        carritoDiv.innerHTML = "<p>El carrito está vacío.</p>";
    } else {
        carritoDiv.innerHTML = "<h2>Carrito de Compras</h2><ul>";
        carritoProductos.forEach((producto, index) => {
            const productoLi = document.createElement('li');
            productoLi.innerHTML = `${producto.nombre} - $${producto.precio} 
                                    <button onclick="eliminarDelCarrito(${index})">Eliminar</button>`;
            carritoDiv.appendChild(productoLi);
        });
        carritoDiv.innerHTML += `<p>Total: $${calcularTotal()}</p>`;
    }
}

function calcularTotal() {
    return carritoProductos.reduce((total, producto) => total + producto.precio, 0);
}

function actualizarCarrito() {
    const carritoBtn = document.getElementById('verCarrito');
    carritoBtn.innerText = `Ver Carrito (${carritoProductos.length})`;
}

function vaciarCarrito() {
    carritoProductos = [];
    localStorage.removeItem('carrito');
    actualizarCarrito();
    mostrarCarrito();
}

verCarritoBtn.addEventListener('click', mostrarCarrito);
vaciarCarritoBtn.addEventListener('click', vaciarCarrito);

mostrarProductos();
actualizarCarrito();


